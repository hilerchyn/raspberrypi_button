import RPi.GPIO as GPIO

led_pin = 24
button_pin = 23

GPIO.setwarnings(False)
GPIO.setmode( GPIO.BCM )
GPIO.setup( led_pin,GPIO.OUT )
GPIO.setup( button_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)

print ("linke r_led pin 24 , linker_button pin 23 (BCM GPIO)\n")

while True:
	if GPIO.input(button_pin):
		GPIO.output(led_pin,True)
	else :
		GPIO.output(led_pin,False)